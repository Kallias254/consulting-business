export default function Process() {
  const steps = [
    {
      number: '01',
      title: 'Discovery Consultation',
      description: 'We listen. We understand where you are, what&apos;s stuck, and what success looks like for you. No judgment, just clarity.'
    },
    {
      number: '02',
      title: 'Custom Strategy',
      description: 'We design a personalized roadmap with clear milestones, timelines, and deliverables tailored to your research and goals.'
    },
    {
      number: '03',
      title: 'Active Support',
      description: 'Regular sessions, detailed feedback on your work, and ongoing guidance through each phase of your dissertation.'
    },
    {
      number: '04',
      title: 'Final Polish',
      description: 'Comprehensive editing, formatting review, and strategic advice as you approach completion and defense.'
    }
  ]

  return (
    <section id="process" className="bg-background py-16 sm:py-20 lg:py-28 border-t border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-foreground">
            Our Proven Process
          </h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
            Four thoughtful phases that move you from stuck to finished
          </p>
        </div>

        <div className="space-y-8">
          {steps.map((step, index) => (
            <div key={index} className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
              {/* Number Column */}
              <div className="md:col-span-2">
                <span className="text-5xl font-serif font-bold text-primary/30">{step.number}</span>
              </div>

              {/* Content Column */}
              <div className="md:col-span-10 space-y-3 pb-8 md:border-b border-border">
                <h3 className="text-xl sm:text-2xl font-serif font-bold text-foreground">
                  {step.title}
                </h3>
                <p className="text-foreground/80 leading-relaxed max-w-2xl">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-secondary/30 rounded-lg p-8 space-y-4 text-center">
          <h3 className="text-xl font-serif font-bold text-foreground">
            Ready to get unstuck?
          </h3>
          <p className="text-foreground/80">
            Let&apos;s talk about your research and what&apos;s next.
          </p>
          <button className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-sm font-medium hover:bg-primary/90 transition-colors">
            Book Your Consultation
          </button>
        </div>
      </div>
    </section>
  )
}
