import { ArrowRight } from 'lucide-react'

export default function Hero() {
  return (
    <section className="bg-background py-16 sm:py-20 lg:py-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-foreground leading-tight text-balance">
              Your dissertation deserves expert support.
            </h1>
            <p className="text-lg text-foreground/80 leading-relaxed max-w-md">
              ScholarCrafted provides personalized coaching, rigorous editing, and structured guidance to help you complete your research with confidence and clarity.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-sm font-medium hover:bg-primary/90 transition-colors">
                Schedule Consultation
                <ArrowRight className="ml-2" size={18} />
              </button>
              <button className="inline-flex items-center justify-center px-6 py-3 border border-primary text-primary rounded-sm font-medium hover:bg-primary/5 transition-colors">
                Learn Our Process
              </button>
            </div>
            
            {/* Trust Indicators */}
            <div className="pt-8 border-t border-border space-y-3">
              <p className="text-sm text-foreground/70 font-medium">Trusted by 500+ graduate students</p>
              <div className="flex flex-wrap gap-6">
                <div>
                  <p className="text-2xl font-bold text-primary">98%</p>
                  <p className="text-xs text-foreground/70">Completion Rate</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary">4.9/5</p>
                  <p className="text-xs text-foreground/70">Average Rating</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary">3 Years</p>
                  <p className="text-xs text-foreground/70">Avg Expertise</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="hidden lg:block">
            <div className="bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg overflow-hidden aspect-square flex items-center justify-center">
              <div className="text-center p-8">
                <div className="w-32 h-32 bg-primary/20 rounded-lg mx-auto mb-6 flex items-center justify-center">
                  <svg className="w-16 h-16 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C6.5 6.253 2 10.998 2 17s4.5 10.747 10 10.747c5.5 0 10-4.998 10-10.747 0-6.002-4.5-10.747-10-10.747z" />
                  </svg>
                </div>
                <h3 className="text-lg font-serif font-bold text-foreground mb-2">Research-Led Guidance</h3>
                <p className="text-sm text-foreground/70">Personalized support based on rigorous academic standards</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
