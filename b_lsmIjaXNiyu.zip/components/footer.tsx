import Link from 'next/link'
import { Mail, Linkedin, Twitter } from 'lucide-react'

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-secondary border-t border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-lg font-serif font-bold text-foreground">
              ScholarCrafted
            </h3>
            <p className="text-sm text-foreground/70 leading-relaxed">
              Expert guidance for graduate students completing their dissertations.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-foreground/70 hover:text-primary transition-colors">
                <Mail size={18} />
              </a>
              <a href="#" className="text-foreground/70 hover:text-primary transition-colors">
                <Linkedin size={18} />
              </a>
              <a href="#" className="text-foreground/70 hover:text-primary transition-colors">
                <Twitter size={18} />
              </a>
            </div>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h4 className="font-serif font-bold text-foreground text-sm">Services</h4>
            <ul className="space-y-2">
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Dissertation Coaching</Link></li>
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Editing Services</Link></li>
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Research Guidance</Link></li>
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Packages</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div className="space-y-4">
            <h4 className="font-serif font-bold text-foreground text-sm">Company</h4>
            <ul className="space-y-2">
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">About Us</Link></li>
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Our Team</Link></li>
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Blog</Link></li>
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Legal */}
          <div className="space-y-4">
            <h4 className="font-serif font-bold text-foreground text-sm">Legal</h4>
            <ul className="space-y-2">
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Privacy Policy</Link></li>
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Terms of Service</Link></li>
              <li><Link href="#" className="text-sm text-foreground/70 hover:text-primary transition-colors">Accessibility</Link></li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="border-t border-border pt-8 flex flex-col sm:flex-row items-center justify-between">
          <p className="text-xs text-foreground/70">
            © {currentYear} ScholarCrafted. All rights reserved.
          </p>
          <p className="text-xs text-foreground/70 mt-4 sm:mt-0">
            Empowering scholars, one dissertation at a time.
          </p>
        </div>
      </div>
    </footer>
  )
}
