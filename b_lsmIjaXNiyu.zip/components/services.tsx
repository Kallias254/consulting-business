import { BookOpen, Lightbulb, FileText } from 'lucide-react'

export default function Services() {
  const services = [
    {
      icon: BookOpen,
      title: 'Dissertation Coaching',
      description: 'One-on-one guidance on research direction, argument structure, and strategic planning. We help you see the forest, not just the trees.',
      features: ['Bi-weekly sessions', 'Custom roadmaps', 'Real-time feedback']
    },
    {
      icon: Lightbulb,
      title: 'Conceptual Development',
      description: 'Clarify your research question, strengthen your theoretical framework, and build a more coherent argument from the ground up.',
      features: ['Idea refinement', 'Literature synthesis', 'Argument mapping']
    },
    {
      icon: FileText,
      title: 'Rigorous Editing',
      description: 'Beyond grammar—we edit for clarity, flow, academic voice, and argumentation. Your writing becomes sharper and more persuasive.',
      features: ['Developmental editing', 'Copy editing', 'Formatting']
    }
  ]

  return (
    <section id="services" className="bg-background py-16 sm:py-20 lg:py-28 border-t border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-foreground">
            How We Help
          </h2>
          <p className="text-lg text-foreground/80 max-w-2xl mx-auto">
            Comprehensive support across every stage of your dissertation journey
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon
            return (
              <div key={index} className="space-y-4 p-6 border border-border rounded-lg hover:border-accent hover:bg-secondary/20 transition-colors">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-serif font-bold text-foreground">
                  {service.title}
                </h3>
                <p className="text-foreground/80 leading-relaxed">
                  {service.description}
                </p>
                <ul className="space-y-2 pt-2">
                  {service.features.map((feature, i) => (
                    <li key={i} className="text-sm text-foreground/70 flex items-start">
                      <span className="text-primary mr-2 font-bold">•</span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            )
          })}
        </div>

        <div className="mt-12 text-center">
          <button className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-sm font-medium hover:bg-primary/90 transition-colors">
            Explore Packages
          </button>
        </div>
      </div>
    </section>
  )
}
