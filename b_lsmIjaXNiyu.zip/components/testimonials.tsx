import { Star } from 'lucide-react'

export default function Testimonials() {
  const testimonials = [
    {
      name: 'Dr. Sarah Chen',
      program: 'PhD in Environmental Science',
      school: 'UC Berkeley',
      quote: 'I was completely lost in Chapter 3. ScholarCrafted helped me restructure my argument and suddenly everything clicked. My advisor was amazed at the clarity.',
      rating: 5
    },
    {
      name: 'James Morrison',
      program: 'Master&apos;s in History',
      school: 'University of Chicago',
      quote: 'The editing feedback was surgical. Not just grammar fixes, but real guidance on academic voice and argument strength. Finished 4 months ahead of schedule.',
      rating: 5
    },
    {
      name: 'Dr. Priya Patel',
      program: 'PhD in Biomedical Engineering',
      school: 'Stanford University',
      quote: 'Having a coach who understood my research and pushed back on weak points made all the difference. I felt supported, not alone. Highly recommend.',
      rating: 5
    }
  ]

  return (
    <section id="testimonials" className="bg-background py-16 sm:py-20 lg:py-28 border-t border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-foreground">
            What Our Scholars Say
          </h2>
          <p className="text-lg text-foreground/80">
            Real feedback from students who finished strong
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="space-y-4 p-8 bg-secondary/20 border border-border rounded-lg">
              {/* Stars */}
              <div className="flex gap-1">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} size={16} className="fill-accent text-accent" />
                ))}
              </div>

              {/* Quote */}
              <blockquote className="text-foreground leading-relaxed italic">
                "{testimonial.quote}"
              </blockquote>

              {/* Author */}
              <div className="border-t border-border pt-4 space-y-1">
                <p className="font-serif font-bold text-foreground">
                  {testimonial.name}
                </p>
                <p className="text-sm text-foreground/70">
                  {testimonial.program}
                </p>
                <p className="text-xs text-foreground/60">
                  {testimonial.school}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
