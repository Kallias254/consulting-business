import Link from 'next/link'
import { ArrowLeft, CheckCircle2 } from 'lucide-react'

interface ServiceTemplateProps {
  title: string
  subtitle: string
  problem: string
  problemDetails: string[]
  whoItIsFor: string[]
  whatWeDo: {
    title: string
    description: string
    deliverables: string[]
  }
  howItWorks: {
    step: number
    title: string
    description: string
  }[]
  expertise: {
    title: string
    points: string[]
  }
  faqs: {
    question: string
    answer: string
  }[]
  ctaText: string
}

export default function ServiceTemplate({
  title,
  subtitle,
  problem,
  problemDetails,
  whoItIsFor,
  whatWeDo,
  howItWorks,
  expertise,
  faqs,
  ctaText,
}: ServiceTemplateProps) {
  return (
    <>
      {/* Hero Section */}
      <section className="bg-primary/5 border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <Link
            href="/services"
            className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors mb-8 font-medium text-sm"
          >
            <ArrowLeft size={16} />
            Back to Services
          </Link>
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-foreground mb-4">
            {title}
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl leading-relaxed">
            {subtitle}
          </p>
        </div>
      </section>

      {/* Problem Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="space-y-6">
          <h2 className="text-3xl font-serif font-bold text-foreground">
            The Challenge
          </h2>
          <p className="text-lg text-foreground leading-relaxed">
            {problem}
          </p>
          <ul className="space-y-3">
            {problemDetails.map((detail, i) => (
              <li key={i} className="flex gap-3">
                <span className="text-primary font-bold flex-shrink-0">•</span>
                <span className="text-muted-foreground">{detail}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Who It's For */}
      <section className="bg-secondary/20 border-y border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-8">
            Who This Is For
          </h2>
          <ul className="grid sm:grid-cols-2 gap-6">
            {whoItIsFor.map((item, i) => (
              <li key={i} className="flex gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-foreground">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* What We Do */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-serif font-bold text-foreground mb-3">
          {whatWeDo.title}
        </h2>
        <p className="text-lg text-foreground leading-relaxed mb-8">
          {whatWeDo.description}
        </p>
        <div className="space-y-4">
          {whatWeDo.deliverables.map((item, i) => (
            <div key={i} className="flex gap-3 bg-secondary/30 p-4 rounded-sm">
              <span className="text-primary font-bold flex-shrink-0">{String.fromCharCode(65 + i)}.</span>
              <span className="text-foreground">{item}</span>
            </div>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-secondary/20 border-y border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-12">
            How It Works
          </h2>
          <div className="space-y-8">
            {howItWorks.map((item, idx) => (
              <div key={idx} className="flex gap-6">
                <div className="flex flex-col items-center flex-shrink-0">
                  <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-lg">
                    {item.step}
                  </div>
                  {idx < howItWorks.length - 1 && (
                    <div className="w-0.5 h-12 bg-border mt-2" />
                  )}
                </div>
                <div className="pb-4">
                  <h3 className="text-xl font-serif font-bold text-foreground mb-2">
                    {item.title}
                  </h3>
                  <p className="text-foreground leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Expertise Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-serif font-bold text-foreground mb-8">
          {expertise.title}
        </h2>
        <div className="grid sm:grid-cols-2 gap-6">
          {expertise.points.map((point, i) => (
            <div key={i} className="border-l-2 border-primary pl-4">
              <p className="text-foreground leading-relaxed">{point}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQs Section */}
      <section className="bg-secondary/10 border-y border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-12">
            Frequently Asked Questions
          </h2>
          <div className="space-y-8">
            {faqs.map((faq, i) => (
              <div key={i} className="space-y-3">
                <h3 className="text-xl font-serif font-bold text-foreground">
                  {faq.question}
                </h3>
                <p className="text-foreground leading-relaxed">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center space-y-6">
          <h2 className="text-4xl font-serif font-bold text-foreground">
            Ready to move forward?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Let&apos;s discuss your specific situation and determine how we can best support your research.
          </p>
          <Link
            href="/consultation"
            className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-sm font-medium hover:bg-primary/90 transition-colors"
          >
            {ctaText}
          </Link>
        </div>
      </section>
    </>
  )
}
