export default function FinalCTA() {
  return (
    <section className="bg-primary text-primary-foreground py-16 sm:py-20 lg:py-28">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
        <div className="space-y-4">
          <h2 className="text-4xl sm:text-5xl font-serif font-bold leading-tight">
            Your dissertation is waiting.
          </h2>
          <p className="text-lg text-primary-foreground/90 leading-relaxed">
            Let&apos;s move from stuck to finished. Schedule a free 30-minute consultation with one of our coaches to discuss your research and create your custom action plan.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
          <button className="px-8 py-4 bg-primary-foreground text-primary rounded-sm font-semibold hover:bg-primary-foreground/90 transition-colors text-lg">
            Schedule Consultation
          </button>
          <button className="px-8 py-4 border-2 border-primary-foreground text-primary-foreground rounded-sm font-semibold hover:bg-primary-foreground/10 transition-colors">
            Learn More
          </button>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8 space-y-2">
          <p className="text-sm text-primary-foreground/80">
            ✓ No pressure, no sales pitch
          </p>
          <p className="text-sm text-primary-foreground/80">
            ✓ 100% confidential
          </p>
          <p className="text-sm text-primary-foreground/80">
            ✓ Cancel anytime with a month's notice
          </p>
        </div>
      </div>
    </section>
  )
}
