export default function Problem() {
  return (
    <section className="bg-background py-16 sm:py-20 lg:py-28 border-t border-border">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-8">
          <div className="text-center space-y-4">
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-foreground">
              Many dissertations languish in limbo.
            </h2>
            <p className="text-lg text-foreground/80 leading-relaxed">
              Graduate students often struggle with isolation, unclear feedback, and the overwhelming scope of independent research. Without structured support, even brilliant research takes years longer than necessary.
            </p>
          </div>

          <div className="border-l-2 border-accent pl-6 py-6 space-y-4">
            <p className="text-foreground leading-relaxed">
              <strong>You&apos;re stuck on methodology.</strong> Your advisor is busy. The literature review seems endless. You&apos;re not sure if your argument is coherent. Self-doubt creeps in.
            </p>
            <p className="text-foreground leading-relaxed">
              <strong>Feedback is sparse or vague.</strong> When you do get comments, they&apos;re often too high-level or contradictory. You need someone who understands your work deeply and can guide you forward.
            </p>
            <p className="text-foreground leading-relaxed">
              <strong>The finish line keeps moving.</strong> You thought you were close, but major revisions loom. Without a clear roadmap, you don&apos;t know if you&apos;re on track or how to get unstuck.
            </p>
          </div>

          <div className="bg-secondary/30 rounded-lg p-8 space-y-4">
            <h3 className="font-serif text-xl font-bold text-foreground">We understand this struggle.</h3>
            <p className="text-foreground/80 leading-relaxed">
              Our team of experienced researchers and dissertation coaches has guided hundreds of students through these exact challenges. We&apos;ve seen what works—and what doesn&apos;t. Now we&apos;re here to help you succeed.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
