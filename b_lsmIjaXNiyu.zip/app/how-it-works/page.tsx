import Navigation from '@/components/navigation'
import Footer from '@/components/footer'
import Link from 'next/link'
import { CheckCircle2, MessageSquare, Calendar, Zap } from 'lucide-react'

export const metadata = {
  title: 'How It Works | ScholarCrafted',
  description: 'Understand the ScholarCrafted process from consultation to completion.',
}

export default function HowItWorksPage() {
  const mainProcess = [
    {
      icon: MessageSquare,
      step: 1,
      title: 'Initial Consultation',
      description: 'We start with a conversation about your research, timeline, and specific challenges. This 30-minute consultation is free and confidential. You&apos;ll tell us where you are and what you need; we&apos;ll explain how we can help.',
      details: [
        'Discuss your project stage and scope',
        'Identify your primary challenges',
        'Explore which services fit your needs',
        'Outline a potential timeline and approach',
      ],
    },
    {
      icon: Calendar,
      step: 2,
      title: 'Customized Plan',
      description: 'After our conversation, we create a tailored plan that matches your needs. Whether coaching, editing, or research support, we explain what to expect and what success looks like.',
      details: [
        'Recommended service(s) based on your needs',
        'Clear timeline and milestone expectations',
        'Explanation of process and deliverables',
        'Pricing and logistics finalized',
      ],
    },
    {
      icon: Zap,
      step: 3,
      title: 'Active Engagement',
      description: 'We begin the work. Whether weekly coaching sessions, editing feedback, or research consultations, we stay in close communication. You always know what to work on next.',
      details: [
        'Regular sessions or touchpoints',
        'Feedback on your work within agreed timelines',
        'Responsive support for questions and challenges',
        'Accountability and progress tracking',
      ],
    },
    {
      icon: CheckCircle2,
      step: 4,
      title: 'Completion & Beyond',
      description: 'As you near completion, we help with final polish, defense preparation, and any last-minute questions. Our relationship doesn&apos;t end at the finish line—we&apos;re here for post-submission support too.',
      details: [
        'Final edits and formatting checks',
        'Defense preparation and Q&A',
        'Celebration of your achievement',
        'Ongoing support if needed',
      ],
    },
  ]

  const principles = [
    {
      title: 'Clarity First',
      description: 'We explain everything clearly. No jargon, no assumptions. You always understand what we&apos;re doing and why.',
    },
    {
      title: 'Your Vision',
      description: 'Your research is yours. We facilitate, guide, and strengthen—we never take over. Your voice, your ideas, your achievement.',
    },
    {
      title: 'Structured Support',
      description: 'We provide clear milestones, timelines, and expectations. You won&apos;t wonder what to work on or what comes next.',
    },
    {
      title: 'Faculty-Led',
      description: 'Our guidance comes from someone with a PhD and active research experience. Academic credibility matters.',
    },
    {
      title: 'Confidential & Safe',
      description: 'Everything you share is confidential. This is a safe space for questions, concerns, and intellectual exploration.',
    },
    {
      title: 'Responsive & Flexible',
      description: 'We adapt to your needs. Life happens. We work around your schedule and adjust our approach as your project evolves.',
    },
  ]

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="bg-primary/5 border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-foreground mb-4">
            How It Works
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl leading-relaxed">
            A clear, simple path from where you are now to completion. No surprises, no complexity—just straightforward guidance and support.
          </p>
        </div>
      </section>

      {/* Main Process */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="space-y-16">
          {mainProcess.map((item, idx) => {
            const Icon = item.icon
            return (
              <div key={idx} className="space-y-6">
                <div className="flex gap-6 items-start">
                  <div className="flex-shrink-0">
                    <div className="w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center">
                      <Icon size={28} strokeWidth={1.5} />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2">
                      <h2 className="text-3xl font-serif font-bold text-foreground">
                        {item.title}
                      </h2>
                    </div>
                    <p className="text-lg text-foreground leading-relaxed mb-6">
                      {item.description}
                    </p>

                    {/* Details List */}
                    <div className="grid sm:grid-cols-2 gap-3 bg-secondary/20 p-6 rounded-sm">
                      {item.details.map((detail, i) => (
                        <div key={i} className="flex gap-2">
                          <span className="text-primary font-bold flex-shrink-0 mt-0.5">•</span>
                          <span className="text-foreground text-sm">{detail}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Divider */}
                {idx < mainProcess.length - 1 && (
                  <div className="flex justify-center">
                    <div className="w-0.5 h-12 bg-border" />
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </section>

      {/* Communication & Expectations */}
      <section className="bg-secondary/10 border-y border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-8">
            What to Expect
          </h2>

          <div className="grid sm:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="text-xl font-serif font-bold text-foreground">
                Communication
              </h3>
              <ul className="space-y-2">
                <li className="flex gap-2">
                  <span className="text-primary font-bold flex-shrink-0">✓</span>
                  <span className="text-foreground">Regular, scheduled sessions</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary font-bold flex-shrink-0">✓</span>
                  <span className="text-foreground">Email support between sessions</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary font-bold flex-shrink-0">✓</span>
                  <span className="text-foreground">Clear feedback and guidance</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary font-bold flex-shrink-0">✓</span>
                  <span className="text-foreground">Progress tracking and accountability</span>
                </li>
              </ul>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-serif font-bold text-foreground">
                You&apos;ll Do the Work
              </h3>
              <ul className="space-y-2">
                <li className="flex gap-2">
                  <span className="text-primary font-bold flex-shrink-0">✓</span>
                  <span className="text-foreground">Write, research, and revise</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary font-bold flex-shrink-0">✓</span>
                  <span className="text-foreground">Take ownership of your work</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary font-bold flex-shrink-0">✓</span>
                  <span className="text-foreground">Engage thoughtfully with feedback</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-primary font-bold flex-shrink-0">✓</span>
                  <span className="text-foreground">Maintain consistent engagement</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Our Principles */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h2 className="text-3xl font-serif font-bold text-foreground mb-12">
          Our Principles
        </h2>

        <div className="grid sm:grid-cols-2 gap-8">
          {principles.map((principle, i) => (
            <div key={i} className="border-l-2 border-primary pl-6">
              <h3 className="text-xl font-serif font-bold text-foreground mb-2">
                {principle.title}
              </h3>
              <p className="text-foreground leading-relaxed">
                {principle.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-secondary/10 border-y border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-12">
            Common Questions
          </h2>

          <div className="space-y-8">
            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                What if I need to pause or change my plan?
              </h3>
              <p className="text-foreground leading-relaxed">
                Life happens. We&apos;re flexible. If you need to pause, reschedule, or adjust your engagement, we work with you. Just communicate early.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                How will I know I&apos;m making progress?
              </h3>
              <p className="text-foreground leading-relaxed">
                We establish clear milestones at the start. You&apos;ll have specific deliverables and timeline markers. You&apos;ll always know what comes next.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                What if I have questions between sessions?
              </h3>
              <p className="text-foreground leading-relaxed">
                Email us. We respond within 24 hours. For quick clarifications, this happens between scheduled sessions. More complex issues are addressed in your next session.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                Will this work with my advisor?
              </h3>
              <p className="text-foreground leading-relaxed">
                Yes. We complement, not replace, your advisor. We provide specialized expertise and support that frees you to focus on your best work. Your advisor remains your primary guide.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                What&apos;s the refund policy?
              </h3>
              <p className="text-foreground leading-relaxed">
                If you&apos;re unsatisfied after your first session, we&apos;ll provide a full refund, no questions asked. We want you to feel confident in our working relationship.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center space-y-6">
          <h2 className="text-4xl font-serif font-bold text-foreground">
            Ready to get started?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Your first step is a free consultation. Let&apos;s talk about where you are and how we can help you succeed.
          </p>
          <Link
            href="/consultation"
            className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-sm font-medium hover:bg-primary/90 transition-colors"
          >
            Schedule Your Free Consultation
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  )
}
