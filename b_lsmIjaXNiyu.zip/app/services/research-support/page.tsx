import Navigation from '@/components/navigation'
import Footer from '@/components/footer'
import ServiceTemplate from '@/components/service-template'

export const metadata = {
  title: 'Research Support | ScholarCrafted',
  description: 'Expert guidance on methodology, analysis, and technical aspects of research.',
}

export default function ResearchSupportPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <ServiceTemplate
        title="Research Support"
        subtitle="Expert guidance on the technical and methodological dimensions of your research. From research design to analysis and interpretation, we help you build a solid foundation for your work."
        problem="Rigorous research requires expertise you may not have in-house. Whether it&apos;s research design, statistical analysis, coding, literature review methodology, or qualitative analysis—getting stuck on technical issues can derail your progress. You need expert guidance without leaving your committee."
        problemDetails={[
          'Uncertainty about research methodology and design choices',
          'Difficulty with statistical analysis or interpretation',
          'Technical coding challenges (Python, R, NVivo, etc.)',
          'Gaps in literature review depth or organization',
          'Questions about data validity, reliability, or ethical considerations',
        ]}
        whoItIsFor={[
          'Students planning their research methodology',
          'Researchers struggling with statistical or qualitative analysis',
          'Those needing help with coding or technical tools',
          'Students building a comprehensive, well-structured literature review',
          'Anyone questioning the rigor or validity of their approach',
        ]}
        whatWeDo={{
          title: 'What We Support',
          description: 'Our research support adapts to your specific needs. We work across methodology, analysis, and technical dimensions.',
          deliverables: [
            'Research Design & Methodology: Help choosing appropriate methods, research questions, and sample sizes',
            'Statistical Support: Guidance on choosing tests, running analyses, and interpreting results',
            'Qualitative Analysis: Support with coding, theme development, and interpretation frameworks',
            'Technical Assistance: Help with coding (R, Python), statistical software, qualitative analysis software',
            'Literature Review: Strategies for organizing, synthesizing, and critically evaluating sources',
            'Data & Ethics: Guidance on data management, privacy, and ethical research practices',
          ],
        }}
        howItWorks={[
          {
            step: 1,
            title: 'Problem Identification',
            description: 'You describe the technical issue, question, or challenge you&apos;re facing. We assess what expertise you need.',
          },
          {
            step: 2,
            title: 'Tailored Support',
            description: 'We provide targeted guidance—could be a consultation, code review, analysis check, or ongoing support.',
          },
          {
            step: 3,
            title: 'Hands-On Help',
            description: 'We work through the problem together: walking through analysis, reviewing code, explaining concepts, or debugging issues.',
          },
          {
            step: 4,
            title: 'Independence & Confidence',
            description: 'You understand the approach, can replicate it, and feel confident moving forward independently.',
          },
        ]}
        expertise={{
          title: 'Our Technical Expertise',
          points: [
            'Multi-disciplinary: Support across humanities, social sciences, and STEM methodologies.',
            'Tool proficiency: Hands-on experience with R, Python, Stata, SPSS, NVivo, Atlas.ti, and more.',
            'Methodological rigor: Deep understanding of qualitative, quantitative, and mixed-methods approaches.',
            'Practical guidance: We explain the "why" behind methods, not just the "how."',
            'Ethical awareness: Integration of data ethics and research integrity throughout.',
          ],
        }}
        faqs={[
          {
            question: 'I don\'t have a coding background. Can you help me learn?',
            answer: 'Absolutely. We help students learn coding from scratch. We teach fundamentals and provide guidance as you build your skills.',
          },
          {
            question: 'Can you help with statistical software like R or Python?',
            answer: 'Yes. We work with R, Python, Stata, SPSS, and other tools. We help you understand both the software and the underlying statistical concepts.',
          },
          {
            question: 'What if my question is about qualitative analysis?',
            answer: 'We support qualitative research too. We can help with coding frameworks, software tools like NVivo, and interpretation strategies.',
          },
          {
            question: 'How is this different from consulting with my advisor?',
            answer: 'We offer specialized technical expertise and one-on-one help with implementation. Your advisor provides disciplinary guidance. Often students benefit from both.',
          },
          {
            question: 'Can you help with a literature review?',
            answer: 'Yes. We help you develop a search strategy, organize findings, and write a strong synthesis. We don\'t write it for you—we guide the process.',
          },
        ]}
        ctaText="Schedule a Research Consultation"
      />
      <Footer />
    </main>
  )
}
