import Navigation from '@/components/navigation'
import Footer from '@/components/footer'
import ServiceTemplate from '@/components/service-template'

export const metadata = {
  title: 'Dissertation Coaching | ScholarCrafted',
  description: 'One-on-one guidance through every stage of your dissertation journey.',
}

export default function DissertationCoachingPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <ServiceTemplate
        title="Dissertation Coaching"
        subtitle="Weekly guidance from proposal through final revision. We help you clarify your thinking, maintain momentum, and reach your goals with confidence."
        problem="Writing a dissertation is isolating. You face conceptual challenges, structural decisions, and emotional valleys—often without adequate guidance. Many students get stuck, revise ineffectively, or lose momentum without knowing how to move forward."
        problemDetails={[
          'Struggling to develop a strong, original research question',
          'Uncertain about structure, organization, and argumentation',
          'Receiving feedback but unsure how to integrate revisions effectively',
          'Feeling isolated and lacking accountability or encouragement',
          'Managing timeline and milestone planning without external structure',
        ]}
        whoItIsFor={[
          'Students at any stage of dissertation writing',
          'Those who have feedback but need help implementing it',
          'Researchers struggling with structure or clarity',
          'Anyone seeking regular, accountable support',
          'Students wanting to accelerate their progress',
        ]}
        whatWeDo={{
          title: 'What We Do',
          description: 'We provide personalized, one-on-one coaching tailored to your project and learning style. You set the agenda; we facilitate clarity, structure, and forward momentum.',
          deliverables: [
            'Weekly 60-minute coaching sessions (frequency and timing flexible)',
            'Feedback on chapter drafts, proposals, and outlines',
            'Structured milestone planning and timeline development',
            'Guidance on integrating feedback and revising effectively',
            'Support with conceptual, structural, and writing challenges',
            'Accountability check-ins and progress tracking',
          ],
        }}
        howItWorks={[
          {
            step: 1,
            title: 'Initial Consultation',
            description: 'We meet to understand your project, timeline, goals, and current challenges. You share your draft materials, and we assess where you need support most.',
          },
          {
            step: 2,
            title: 'Tailored Plan',
            description: 'We develop a coaching plan that matches your needs. This includes session frequency, focus areas, and milestone timeline.',
          },
          {
            step: 3,
            title: 'Regular Coaching',
            description: 'You attend weekly (or bi-weekly) sessions. We discuss your work, address challenges, provide feedback, and help you plan next steps.',
          },
          {
            step: 4,
            title: 'Ongoing Support',
            description: 'As your project evolves, we adjust our approach. You always know what to work on and why, with clear accountability and progress markers.',
          },
        ]}
        expertise={{
          title: 'Our Approach',
          points: [
            'Faculty-led: Coached by someone with a PhD and active research experience.',
            'Holistic: We address conceptual, structural, and emotional dimensions of dissertation writing.',
            'Flexible: Sessions adapt to your needs—sometimes discussing ideas, sometimes reviewing text.',
            'Confidential: Safe space for questions, concerns, and intellectual exploration.',
            'Structured: Clear milestones and expectations keep you on track.',
          ],
        }}
        faqs={[
          {
            question: 'How long does coaching typically last?',
            answer: 'This depends on where you are in the process. Some students work with us for 6 months through defense prep; others engage for a year or more. We discuss your timeline during your initial consultation.',
          },
          {
            question: 'What if I only need help with one specific issue?',
            answer: 'You can start with a limited number of sessions to address a specific challenge. Many students then continue with ongoing coaching, but short-term engagements are absolutely possible.',
          },
          {
            question: 'Do you provide feedback on drafts between sessions?',
            answer: 'Yes. During our regular coaching, we review drafts you submit. Beyond that, additional detailed feedback can be arranged separately.',
          },
          {
            question: 'How does coaching differ from editing?',
            answer: 'Coaching is about helping you clarify your thinking and plan your work. Editing is about refining the writing itself. Many students benefit from both—coaching early and editing later.',
          },
          {
            question: 'Can you work with students in any discipline?',
            answer: 'We work with students across humanities, social sciences, and some STEM fields. If you&apos;re unsure, just ask during your initial consultation.',
          },
        ]}
        ctaText="Book a Consultation"
      />
      <Footer />
    </main>
  )
}
