import Navigation from '@/components/navigation'
import Footer from '@/components/footer'
import Link from 'next/link'
import { BookOpen, PenTool, Microscope, ArrowRight } from 'lucide-react'

export const metadata = {
  title: 'Our Services | ScholarCrafted',
  description: 'Comprehensive dissertation and research support services designed for graduate students',
}

export default function ServicesPage() {
  const services = [
    {
      icon: BookOpen,
      title: 'Dissertation Coaching',
      slug: 'dissertation-coaching',
      description: 'One-on-one guidance through every stage of your dissertation journey. From proposal development to final revisions, we help you clarify your thinking and move forward with confidence.',
      features: [
        'Weekly coaching sessions',
        'Feedback on drafts',
        'Milestone planning',
        'Structure guidance',
      ],
    },
    {
      icon: PenTool,
      title: 'Editing & Proofreading',
      slug: 'editing-proofreading',
      description: 'Professional editing that strengthens your voice and argumentation. We work with your ideas, not against them, to help your research shine.',
      features: [
        'Developmental editing',
        'Copy editing',
        'Proofreading',
        'Format review',
      ],
    },
    {
      icon: Microscope,
      title: 'Research Support',
      slug: 'research-support',
      description: 'Specialized guidance on methodology, analysis, and technical aspects of research. Whether coding, statistics, or literature review, we provide expert support.',
      features: [
        'Methodology consultation',
        'Technical guidance',
        'Literature review support',
        'Analysis review',
      ],
    },
  ]

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28">
        <div className="space-y-4 mb-16">
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-foreground leading-tight">
            Our Services
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl">
            Comprehensive support designed to help you succeed at every stage of your research and dissertation journey.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid gap-12 sm:gap-8">
          {services.map((service) => {
            const Icon = service.icon
            return (
              <div
                key={service.slug}
                className="border-b border-border pb-12 sm:pb-8 last:border-b-0"
              >
                <div className="flex gap-4 sm:gap-6 items-start">
                  <div className="flex-shrink-0">
                    <Icon className="w-8 h-8 text-primary mt-1" strokeWidth={1.5} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h2 className="text-2xl sm:text-3xl font-serif font-bold text-foreground mb-2">
                      {service.title}
                    </h2>
                    <p className="text-base text-foreground mb-4 leading-relaxed">
                      {service.description}
                    </p>

                    {/* Features List */}
                    <div className="grid grid-cols-2 gap-2 mb-6">
                      {service.features.map((feature) => (
                        <div key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary/60" />
                          {feature}
                        </div>
                      ))}
                    </div>

                    {/* Learn More Link */}
                    <Link
                      href={`/services/${service.slug}`}
                      className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors font-medium text-sm"
                    >
                      Learn more
                      <ArrowRight size={16} />
                    </Link>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary/5 border-t border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center space-y-4">
            <h2 className="text-3xl font-serif font-bold text-foreground">
              Not sure which service is right for you?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Book a free consultation to discuss your needs. We&apos;ll help you determine the best path forward.
            </p>
            <div className="pt-4">
              <Link
                href="/consultation"
                className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-sm font-medium hover:bg-primary/90 transition-colors"
              >
                Book Your Consultation
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
