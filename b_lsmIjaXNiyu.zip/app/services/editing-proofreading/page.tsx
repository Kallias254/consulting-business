import Navigation from '@/components/navigation'
import Footer from '@/components/footer'
import ServiceTemplate from '@/components/service-template'

export const metadata = {
  title: 'Editing & Proofreading | ScholarCrafted',
  description: 'Professional editing that strengthens your voice and argumentation.',
}

export default function EditingProofreadingPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <ServiceTemplate
        title="Editing & Proofreading"
        subtitle="Professional editing that strengthens your argument without changing your voice. From developmental feedback to final proofreading, we refine your research for maximum clarity and impact."
        problem="After months of writing, it&apos;s hard to see your own work objectively. Weak organization goes unnoticed. Arguments don&apos;t land. Redundancies clutter your prose. Generic editing services apply surface-level fixes, missing the deeper structural and conceptual issues that weaken your research."
        problemDetails={[
          'Structural issues that undermine your argument',
          'Unclear or contradictory phrasing that confuses readers',
          'Excessive length or redundancy that obscures your ideas',
          'Inconsistent formatting and citation style',
          'Grammatical and punctuation errors that look unprofessional',
        ]}
        whoItIsFor={[
          'Students with complete or near-complete drafts',
          'Those seeking feedback on structure and organization',
          'Researchers wanting stronger, clearer prose',
          'Anyone preparing for final submission or defense',
          'Non-native English speakers seeking polish',
        ]}
        whatWeDo={{
          title: 'Our Editing Services',
          description: 'We offer tiered editing levels, so you get exactly what you need. Most dissertations benefit from developmental editing; final polish comes later.',
          deliverables: [
            'Developmental Editing: Deep-dive feedback on structure, organization, argument flow, and conceptual clarity',
            'Substantive Editing: Clarification of language, reorganization of weak sections, and strengthening of connections',
            'Copy Editing: Grammar, style, consistency, and sentence-level clarity',
            'Proofreading: Final check for typos, formatting, and citation accuracy',
            'Format Review: Verification of compliance with your institution&apos;s dissertation guidelines',
          ],
        }}
        howItWorks={[
          {
            step: 1,
            title: 'Submit Your Draft',
            description: 'You send your chapter(s) or full draft along with any specific questions or concerns. We review the scope and complexity.',
          },
          {
            step: 2,
            title: 'Initial Assessment',
            description: 'We provide an estimate of editing needs and discuss which level(s) of editing suit your work best.',
          },
          {
            step: 3,
            title: 'Editing Process',
            description: 'We edit the draft using tracked changes, detailed margin comments, and (if needed) a summary memo explaining major revisions.',
          },
          {
            step: 4,
            title: 'Delivery & Discussion',
            description: 'You receive the edited manuscript and can request a brief discussion of major changes or recommendations.',
          },
        ]}
        expertise={{
          title: 'Why Our Editing Is Different',
          points: [
            'Faculty perspective: Edited by someone trained in academic writing and research communication.',
            'Deep reading: We don&apos;t just fix grammar—we strengthen your logic and clarity.',
            'Respectful: We preserve your voice and ideas while making them stronger.',
            'Transparent: You see exactly what changed and why through detailed comments.',
            'Discipline-aware: We understand the conventions and expectations of academic writing across fields.',
          ],
        }}
        faqs={[
          {
            question: 'How long does editing take?',
            answer: 'It depends on length, complexity, and editing level. A 50-page chapter with developmental editing might take 2-3 weeks. Proofreading is faster. We provide timelines upfront.',
          },
          {
            question: 'How much does editing cost?',
            answer: 'Pricing depends on word count and editing level. We&apos;ll provide a quote after discussing your needs. Most students edit chapters progressively rather than the entire dissertation at once.',
          },
          {
            question: 'Will editing remove my voice?',
            answer: 'Never. Our role is to clarify your ideas and strengthen your expression—not rewrite your work. You retain full ownership and control.',
          },
          {
            question: 'Can you edit while I&apos;m still drafting?',
            answer: 'Yes, though developmental editing is most useful once you have a solid draft. Many students send chapters incrementally as they finish them.',
          },
          {
            question: 'Do you work with non-native English speakers?',
            answer: 'Absolutely. We specialize in helping non-native English writers strengthen clarity and polish their prose to academic standards.',
          },
        ]}
        ctaText="Request an Editing Quote"
      />
      <Footer />
    </main>
  )
}
