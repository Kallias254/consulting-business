import Navigation from '@/components/navigation'
import Footer from '@/components/footer'
import Link from 'next/link'
import { Award, Users, BookOpen, Lightbulb } from 'lucide-react'

export const metadata = {
  title: 'About ScholarCrafted | Meet Micah',
  description: 'Learn about ScholarCrafted and our faculty-led approach to dissertation support.',
}

export default function AboutPage() {
  const values = [
    {
      icon: Award,
      title: 'Academic Rigor',
      description: 'Our guidance is grounded in doctoral-level expertise and research experience. We understand the standards and expectations of academic work.',
    },
    {
      icon: Users,
      title: 'Genuine Partnership',
      description: 'We see ourselves as collaborators in your success. Your goals are our goals. Your challenges are our challenges.',
    },
    {
      icon: BookOpen,
      title: 'Intellectual Growth',
      description: 'Beyond the dissertation, we&apos;re invested in your development as a scholar. We want to strengthen not just your work, but you as a researcher.',
    },
    {
      icon: Lightbulb,
      title: 'Clarity & Simplicity',
      description: 'Academic work is complex enough. Our guidance is clear, direct, and free from jargon. You always understand what we&apos;re doing and why.',
    },
  ]

  const credentials = [
    'PhD in [Your Field], [University]',
    '10+ years of research and academic experience',
    'Published author and active researcher',
    'Former graduate student—understands the journey',
    'Faculty experience teaching and mentoring',
    'Deep expertise in dissertation structure and methodology',
  ]

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="bg-primary/5 border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-foreground mb-4">
            About ScholarCrafted
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl leading-relaxed">
            Founded on a simple belief: every doctoral student deserves expert guidance, intellectual partnership, and support from someone who&apos;s been there.
          </p>
        </div>
      </section>

      {/* ScholarCrafted Story */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <div className="space-y-8">
          <div>
            <h2 className="text-3xl font-serif font-bold text-foreground mb-4">
              Our Story
            </h2>
            <p className="text-lg text-foreground leading-relaxed mb-4">
              ScholarCrafted exists because we believe dissertation writing doesn&apos;t have to be isolating. Too many brilliant researchers struggle alone—stuck on structural questions, second-guessing their methodology, or simply lacking someone to bounce ideas off.
            </p>
            <p className="text-lg text-foreground leading-relaxed mb-4">
              We started ScholarCrafted to change that. Our model is simple: provide expert, faculty-led guidance that treats students as intellectual partners rather than clients. We&apos;re invested in your success because we believe in the research you&apos;re doing.
            </p>
            <p className="text-lg text-foreground leading-relaxed">
              Whether it&apos;s conceptual clarity, structural guidance, technical expertise, or polished prose, we offer the support that helps you produce your best work.
            </p>
          </div>
        </div>
      </section>

      {/* Faculty Lead Section */}
      <section className="bg-secondary/10 border-y border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-12">
            Meet Micah
          </h2>

          <div className="grid sm:grid-cols-3 gap-8 items-start">
            {/* Photo Placeholder */}
            <div className="sm:col-span-1">
              <div className="bg-primary/10 rounded-sm aspect-square flex items-center justify-center text-muted-foreground border border-border">
                <span className="text-sm">Photo</span>
              </div>
              <p className="text-sm text-muted-foreground mt-3 text-center italic">
                PhD Student & Research Scholar
              </p>
            </div>

            {/* Bio */}
            <div className="sm:col-span-2 space-y-6">
              <p className="text-lg text-foreground leading-relaxed">
                Micah is the faculty lead at ScholarCrafted and brings 10+ years of research and academic experience to the table. With a PhD in [Your Field] and active involvement in current research, Micah understands both the intellectual demands and emotional challenges of dissertation work.
              </p>

              <div className="space-y-4">
                <h3 className="text-lg font-serif font-bold text-foreground">
                  Experience & Credentials
                </h3>
                <ul className="space-y-2">
                  {credentials.map((cred, i) => (
                    <li key={i} className="flex gap-3">
                      <span className="text-primary font-bold flex-shrink-0">✓</span>
                      <span className="text-foreground">{cred}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <p className="text-foreground leading-relaxed italic">
                But more importantly, Micah was once where you are—navigating the uncertainty of dissertation writing. That lived experience shapes everything we do at ScholarCrafted.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Philosophy */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <h2 className="text-3xl font-serif font-bold text-foreground mb-12">
          Our Philosophy
        </h2>

        <div className="space-y-8">
          <div className="border-l-4 border-primary pl-6">
            <h3 className="text-xl font-serif font-bold text-foreground mb-2">
              1. Intellectual Partnership
            </h3>
            <p className="text-foreground leading-relaxed">
              We don&apos;t treat you as a client; we treat you as an intellectual partner. Your ideas matter. Your questions are valid. We create space for genuine intellectual dialogue.
            </p>
          </div>

          <div className="border-l-4 border-primary pl-6">
            <h3 className="text-xl font-serif font-bold text-foreground mb-2">
              2. Faculty-Led Guidance
            </h3>
            <p className="text-foreground leading-relaxed">
              Our guidance comes from someone with a PhD and active research experience. We understand academic standards, methodology rigor, and the intellectual expectations of your field.
            </p>
          </div>

          <div className="border-l-4 border-primary pl-6">
            <h3 className="text-xl font-serif font-bold text-foreground mb-2">
              3. Clarity Over Complexity
            </h3>
            <p className="text-foreground leading-relaxed">
              Academic writing is complex. We simplify guidance without dumbing it down. We explain the why behind recommendations, empowering you to make informed decisions.
            </p>
          </div>

          <div className="border-l-4 border-primary pl-6">
            <h3 className="text-xl font-serif font-bold text-foreground mb-2">
              4. Your Work, Your Voice
            </h3>
            <p className="text-foreground leading-relaxed">
              We strengthen your ideas and prose; we never rewrite your work. You remain the author. Your voice, perspective, and intellectual vision are paramount.
            </p>
          </div>

          <div className="border-l-4 border-primary pl-6">
            <h3 className="text-xl font-serif font-bold text-foreground mb-2">
              5. Confidential & Safe
            </h3>
            <p className="text-foreground leading-relaxed">
              Everything you share is confidential. This is a judgment-free space for intellectual exploration, questions, and vulnerability.
            </p>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="bg-secondary/10 border-y border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-12">
            Our Values
          </h2>

          <div className="grid sm:grid-cols-2 gap-8">
            {values.map((value, i) => {
              const Icon = value.icon
              return (
                <div key={i} className="space-y-3">
                  <div className="flex gap-3 items-start">
                    <Icon className="w-6 h-6 text-primary flex-shrink-0 mt-0.5" />
                    <h3 className="text-lg font-serif font-bold text-foreground">
                      {value.title}
                    </h3>
                  </div>
                  <p className="text-foreground leading-relaxed">
                    {value.description}
                  </p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Team Structure */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <h2 className="text-3xl font-serif font-bold text-foreground mb-8">
          How We Work
        </h2>

        <div className="space-y-8">
          <div className="border border-border p-6 rounded-sm bg-secondary/20">
            <h3 className="text-xl font-serif font-bold text-foreground mb-3">
              Faculty Oversight
            </h3>
            <p className="text-foreground leading-relaxed">
              Every engagement at ScholarCrafted is led or directly overseen by Micah. You&apos;re not working with junior contractors—you&apos;re working with someone qualified to provide expert academic guidance.
            </p>
          </div>

          <div className="border border-border p-6 rounded-sm bg-secondary/20">
            <h3 className="text-xl font-serif font-bold text-foreground mb-3">
              Specialized Expertise
            </h3>
            <p className="text-foreground leading-relaxed">
              Depending on your needs, we may bring in specialized expertise (statistics, coding, technical writing). But all work is coordinated under faculty leadership to ensure consistency and quality.
            </p>
          </div>

          <div className="border border-border p-6 rounded-sm bg-secondary/20">
            <h3 className="text-xl font-serif font-bold text-foreground mb-3">
              Committed to Your Success
            </h3>
            <p className="text-foreground leading-relaxed">
              We succeed when you succeed. Your achievement is our achievement. We&apos;re not transactional; we&apos;re genuinely invested in seeing you complete your dissertation and launch your academic career.
            </p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center space-y-6">
          <h2 className="text-4xl font-serif font-bold text-foreground">
            Join Us
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Whether you&apos;re in the proposal stage or polishing chapters, ScholarCrafted is here to support your research and your success.
          </p>
          <Link
            href="/consultation"
            className="inline-block px-8 py-3 bg-primary text-primary-foreground rounded-sm font-medium hover:bg-primary/90 transition-colors"
          >
            Book a Consultation
          </Link>
        </div>
      </section>

      <Footer />
    </main>
  )
}
