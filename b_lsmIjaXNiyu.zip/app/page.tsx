import Navigation from '@/components/navigation'
import Hero from '@/components/hero'
import Problem from '@/components/problem'
import Services from '@/components/services'
import Process from '@/components/process'
import Testimonials from '@/components/testimonials'
import FinalCTA from '@/components/final-cta'
import Footer from '@/components/footer'

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <Hero />
      <Problem />
      <Services />
      <Process />
      <Testimonials />
      <FinalCTA />
      <Footer />
    </main>
  )
}
