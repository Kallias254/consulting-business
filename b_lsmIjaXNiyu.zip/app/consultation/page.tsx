'use client'

import Navigation from '@/components/navigation'
import Footer from '@/components/footer'
import { useState } from 'react'
import { Calendar, Clock, Shield } from 'lucide-react'

export default function ConsultationPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    stage: '',
    projectType: '',
    challenge: '',
    preferredTime: '',
  })

  const [submitted, setSubmitted] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    // Here you would typically send the form data to your backend
    console.log('Form submitted:', formData)
    setSubmitted(true)
    // Reset form after a delay
    setTimeout(() => {
      setSubmitted(false)
      setFormData({
        name: '',
        email: '',
        stage: '',
        projectType: '',
        challenge: '',
        preferredTime: '',
      })
    }, 3000)
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="bg-primary/5 border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
          <h1 className="text-4xl sm:text-5xl font-serif font-bold text-foreground mb-4">
            Book a Consultation
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl leading-relaxed">
            Let&apos;s talk about your research and how we can support you. This 30-minute consultation is free and will help us understand your needs.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <div className="grid sm:grid-cols-3 gap-12">
          {/* Form */}
          <div className="sm:col-span-2">
            {submitted ? (
              <div className="bg-secondary/30 border border-primary p-8 rounded-sm text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground mx-auto flex items-center justify-center">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 className="text-2xl font-serif font-bold text-foreground">
                  Thank you!
                </h2>
                <p className="text-foreground">
                  We&apos;ve received your submission. We&apos;ll be in touch within 24 hours to schedule your consultation.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Name */}
                <div className="space-y-2">
                  <label htmlFor="name" className="block text-sm font-medium text-foreground">
                    Name <span className="text-primary">*</span>
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-border rounded-sm bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    placeholder="Your name"
                  />
                </div>

                {/* Email */}
                <div className="space-y-2">
                  <label htmlFor="email" className="block text-sm font-medium text-foreground">
                    Email <span className="text-primary">*</span>
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-border rounded-sm bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                    placeholder="your.email@university.edu"
                  />
                </div>

                {/* Stage */}
                <div className="space-y-2">
                  <label htmlFor="stage" className="block text-sm font-medium text-foreground">
                    What stage is your research at? <span className="text-primary">*</span>
                  </label>
                  <select
                    id="stage"
                    name="stage"
                    value={formData.stage}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-border rounded-sm bg-card text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">Select a stage...</option>
                    <option value="proposal">Working on proposal/plan</option>
                    <option value="early-drafting">Early drafting (1-2 chapters)</option>
                    <option value="mid-drafting">Mid-stage (3+ chapters, still writing)</option>
                    <option value="revision">Revision and refinement</option>
                    <option value="final">Final stages/defense prep</option>
                    <option value="planning">Still planning my approach</option>
                  </select>
                </div>

                {/* Project Type */}
                <div className="space-y-2">
                  <label htmlFor="projectType" className="block text-sm font-medium text-foreground">
                    What type of project is this? <span className="text-primary">*</span>
                  </label>
                  <select
                    id="projectType"
                    name="projectType"
                    value={formData.projectType}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-2 border border-border rounded-sm bg-card text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">Select a project type...</option>
                    <option value="dissertation">Dissertation</option>
                    <option value="thesis">Thesis</option>
                    <option value="research-paper">Research paper/capstone</option>
                    <option value="other">Other academic project</option>
                  </select>
                </div>

                {/* Primary Challenge */}
                <div className="space-y-2">
                  <label htmlFor="challenge" className="block text-sm font-medium text-foreground">
                    What&apos;s your primary challenge right now?
                  </label>
                  <textarea
                    id="challenge"
                    name="challenge"
                    value={formData.challenge}
                    onChange={handleChange}
                    rows={4}
                    className="w-full px-4 py-2 border border-border rounded-sm bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none"
                    placeholder="E.g., struggling with structure, unclear methodology, need editing help, etc."
                  />
                </div>

                {/* Preferred Time */}
                <div className="space-y-2">
                  <label htmlFor="preferredTime" className="block text-sm font-medium text-foreground">
                    Preferred time for consultation
                  </label>
                  <select
                    id="preferredTime"
                    name="preferredTime"
                    value={formData.preferredTime}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-border rounded-sm bg-card text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                  >
                    <option value="">No preference</option>
                    <option value="morning">Morning (9am-12pm)</option>
                    <option value="afternoon">Afternoon (12pm-5pm)</option>
                    <option value="evening">Evening (5pm-8pm)</option>
                    <option value="weekends">Weekends</option>
                  </select>
                </div>

                {/* Consent & Privacy */}
                <div className="bg-secondary/20 border border-border p-4 rounded-sm text-sm text-muted-foreground">
                  <p>
                    Your information is completely confidential. We won&apos;t share it with anyone or spam you. We&apos;ll only use it to schedule your consultation and follow up about our services.
                  </p>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-primary text-primary-foreground rounded-sm font-medium hover:bg-primary/90 transition-colors text-lg"
                >
                  Request Consultation
                </button>
              </form>
            )}
          </div>

          {/* Sidebar Info */}
          <div className="sm:col-span-1 space-y-6">
            <div className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex gap-3 items-start">
                <Clock size={20} className="text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-serif font-bold text-foreground">
                    How long?
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    30 minutes
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex gap-3 items-start">
                <Calendar size={20} className="text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-serif font-bold text-foreground">
                    What to expect
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    We&apos;ll discuss your project, challenges, and how we can help
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-3 border-l-4 border-primary pl-4">
              <div className="flex gap-3 items-start">
                <Shield size={20} className="text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-serif font-bold text-foreground">
                    Confidential
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Everything you share is private and secure
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-secondary/30 border border-border p-4 rounded-sm space-y-3">
              <h3 className="font-serif font-bold text-foreground">
                Questions?
              </h3>
              <p className="text-sm text-muted-foreground">
                Email us at{' '}
                <a href="mailto:hello@scholarcrafted.com" className="text-primary hover:text-primary/80">
                  hello@scholarcrafted.com
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="bg-secondary/10 border-y border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <h2 className="text-3xl font-serif font-bold text-foreground mb-12">
            Consultation FAQs
          </h2>

          <div className="grid sm:grid-cols-2 gap-8">
            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                Is this consultation free?
              </h3>
              <p className="text-foreground leading-relaxed">
                Yes. Your 30-minute consultation is completely free. No obligation to move forward.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                How is this scheduled?
              </h3>
              <p className="text-foreground leading-relaxed">
                After you submit this form, we&apos;ll email you within 24 hours with available times. You pick what works for you.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                What if I can&apos;t make a time?
              </h3>
              <p className="text-foreground leading-relaxed">
                Let us know. We&apos;re flexible and will work with your schedule. We offer morning, afternoon, and evening slots.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                Will you pressure me to sign up?
              </h3>
              <p className="text-foreground leading-relaxed">
                No. Our goal is to understand your needs and discuss how we might help. The choice to move forward is entirely yours.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                What if I have more questions first?
              </h3>
              <p className="text-foreground leading-relaxed">
                Email us at hello@scholarcrafted.com. We&apos;re happy to answer any questions before you book.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-serif font-bold text-foreground">
                Is the consultation confidential?
              </h3>
              <p className="text-foreground leading-relaxed">
                Completely. Everything you share is confidential. We don&apos;t share information with your institution or anyone else.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
